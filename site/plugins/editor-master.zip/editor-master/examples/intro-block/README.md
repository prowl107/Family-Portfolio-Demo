# Intro block extension

This demo block shows how to extend an existing block to just slightly modify the style or some methods.

## Installation

You can install this demo extension as a regular Kirby plugin by placing the intro-block folder in site/plugins

## Docs

I've added lots of annotations to the index.php, index.css and index.js to give you a better idea how things work.
