<?php

return [
    [
        'content' => 'Item A',
        'type' => 'ol',
    ],
    [
        'content' => 'Item B',
        'type' => 'ol',
    ]
];
