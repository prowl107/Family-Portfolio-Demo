<?php

return [
    [
        'content' => 'Paragraph',
        'type' => 'paragraph',
    ]
];
