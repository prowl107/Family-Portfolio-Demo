<?php

return [
    [
        'type' => 'hr'
    ]
];
