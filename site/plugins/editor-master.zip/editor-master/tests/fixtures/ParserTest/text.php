<?php

return [
    [
        'content' => 'Text',
        'type' => 'paragraph',
    ],
];
