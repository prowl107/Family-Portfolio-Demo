<?php

return [
    [
        'type' => 'kirbytext',
        'content' => '<iframe src="https://whatever.com"></iframe>'
    ],
];
