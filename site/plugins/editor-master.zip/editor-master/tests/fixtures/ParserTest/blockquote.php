<?php

return [
    [
        'content' => 'Blockquote',
        'type' => 'blockquote',
    ]
];
