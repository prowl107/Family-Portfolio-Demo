<?php

return [
    [
        'content' => "<table>\n <tr>\n <td>Test</td>\n </tr>\n</table>",
        'type'    => 'kirbytext',
    ],
];
