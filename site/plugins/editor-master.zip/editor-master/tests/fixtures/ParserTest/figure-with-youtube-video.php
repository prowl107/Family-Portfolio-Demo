<?php

return [
    [
        'type' => 'video',
        'attrs' => [
            'src'     => 'https://youtube.com/watch?v=LccqV6HPZrw',
            'caption' => 'Caption'
        ]
    ],
];
