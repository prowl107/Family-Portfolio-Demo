<?php

return [
    [
        'content' => 'Paragraph A',
        'type' => 'paragraph',
    ],
    [
        'content' => 'Paragraph B',
        'type' => 'paragraph',
    ],
    [
        'content' => 'Paragraph C',
        'type' => 'paragraph',
    ],
];
