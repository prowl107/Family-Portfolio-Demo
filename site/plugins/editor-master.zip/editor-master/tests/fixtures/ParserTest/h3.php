<?php

return [
    [
        'content' => 'Heading',
        'type' => 'h3'
    ]
];
