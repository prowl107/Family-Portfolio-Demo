<?php

return [
    [
        'type' => 'image',
        'attrs' => [
            'src'  => 'https://example.com/test.jpg',
            'alt'  => 'Image',
            'link' => null
        ]
    ],
];
