<?php

return [
    [
        'content' => 'Text <strong>with</strong> <em>Markup</em>',
        'type' => 'paragraph',
    ],
];
