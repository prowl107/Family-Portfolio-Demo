<?php

return [
    [
        'content' => 'Item A',
        'type' => 'ul',
    ],
    [
        'content' => 'Item B',
        'type' => 'ul',
    ]
];
