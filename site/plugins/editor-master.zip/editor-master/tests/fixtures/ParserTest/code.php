<?php

return [
    [
        'content' => 'Code',
        'type' => 'code',
        'attrs' => [
            'language' => null
        ]
    ]
];
