<?php

return [
    [
        'type' => 'image',
        'attrs' => [
            'src'     => 'https://example.com/test.jpg',
            'alt'     => 'Image',
            'caption' => 'Caption',
            'link'    => null
        ]
    ],
];
