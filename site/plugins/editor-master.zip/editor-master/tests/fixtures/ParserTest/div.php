<?php

return [
    [
        'content' => 'DIV Content',
        'type' => 'paragraph',
    ],
];
