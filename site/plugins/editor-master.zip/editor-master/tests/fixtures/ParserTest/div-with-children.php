<?php

return [
    [
        'content' => 'Heading',
        'type' => 'h1',
        'attrs' => [
            'id' => null
        ]
    ],
    [
        'content' => 'Paragraph',
        'type' => 'paragraph',
    ],
    [
        'type' => 'hr',
    ],
];
