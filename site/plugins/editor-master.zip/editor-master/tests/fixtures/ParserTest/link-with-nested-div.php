<?php

return [
    [
        'content' => '<a href="/test">A B</a>',
        'type' => 'paragraph',
    ]
];
