<?php

return [
    [
        'content' => 'A B C',
        'type' => 'paragraph',
    ],
];
