<?php

return [
    [
        'content' => 'Not empty 1',
        'type' => 'paragraph',
    ],
    [
        'content' => 'Not empty 2',
        'type' => 'paragraph',
    ],
    [
        'content' => 'Not empty 3',
        'type' => 'paragraph',
    ],
];
