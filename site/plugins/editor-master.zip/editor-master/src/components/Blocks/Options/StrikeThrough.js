export default {
  icon: "strikethrough",
  label: "Strike-through",
  type: "strikeThrough",
  action: "toggleMark",
  args: ["strikeThrough"]
};
