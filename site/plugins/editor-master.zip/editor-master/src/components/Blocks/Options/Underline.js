export default {
  icon: "underline",
  label: "Underline",
  type: "underline",
  action: "toggleMark",
  args: ["underline"]
};
