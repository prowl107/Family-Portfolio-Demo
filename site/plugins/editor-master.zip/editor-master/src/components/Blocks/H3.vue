<script>
import H1 from "./H1.vue";

export default {
  ...H1
};
</script>

<style lang="scss">
.k-editor-h3-block .k-editable-placeholder,
.k-editor-h3-block .ProseMirror {
  font-size: 1rem;
  font-weight: 600;
  line-height: 1.5em;
}
</style>
