---
name: Feature request
about: Ask for a new feature

---

<!--
Tell us some more about your idea.
Make sure that the same feature has not been suggested yet.
-->
